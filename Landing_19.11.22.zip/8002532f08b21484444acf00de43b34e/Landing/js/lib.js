
//Приветствие
export function hello()
{
let p;
p=document.getElementById('anime');
p.innerHTML=" Hello ";
//({"color": "blue"});
$("#anime").css( {"color":"#DC143C"});
const element = document.querySelector('.effect');
element.classList.add('animate__animated', 'animate__backInLeft');
element.style.setProperty('--animate-duration', '5s');

// Выполнение кода просле завершения прихода текста
element.addEventListener('animationend', () => 
{
p=document.getElementById('anime');
p.innerHTML=" Hello ";
$("#anime").css( {"color":"#DC143C"});
const element = document.querySelector('.effect');
element.classList.add('animate__animated', 'animate__backOutLeft');
element.style.setProperty('--animate-duration', '3s');

// Выполнение кода просле завершения ухода текста	
element.addEventListener('animationend', () => 
{
// Удаление всех дочерних элементов
var element = document.getElementById("anime");
while (element.firstChild) {
element.removeChild(element.firstChild);
}
});

console.log("Анимация подключена");
}); 
}

// Колеблется текст при наведении
function jello()
{
const element = document.getElementById('effect');
element.classList.add('animate__animated', 'animate__tada');
element.style.setProperty('--animate-duration', '0.5s');
element.style.animation = 'none';
element.offsetHeight; /* trigger reflow */
element.style.animation = null; 
console.log("Анимация Jello подключена");
}
function jello1()
{
const element = document.getElementById('effect1');
element.classList.add('animate__animated', 'animate__tada');
element.style.setProperty('--animate-duration', '0.5s');
element.style.animation = 'none';
element.offsetHeight; 
element.style.animation = null; 
console.log("Анимация Jello подключена");
}
function jello2()
{
const element = document.getElementById('effect2');
element.classList.add('animate__animated', 'animate__tada');
element.style.setProperty('--animate-duration', '0.5s');
element.style.animation = 'none';
element.offsetHeight; /* trigger reflow */
element.style.animation = null; 
console.log("Анимация Jello подключена");
}
function jello3()
{
const element = document.getElementById('effect3');
element.classList.add('animate__animated', 'animate__tada');
element.style.setProperty('--animate-duration', '0.5s');
element.style.animation = 'none';
element.offsetHeight; /* trigger reflow */
element.style.animation = null; 
console.log("Анимация Jello подключена");
}

export function Initjello()
{  
	$('#effect').hover(jello);
	console.log("Работает jello");
}
export function Initjello1()
{  
	$('#effect1').hover(jello1);
	console.log("Работает jello");
}
export function Initjello2()
{  
	$('#effect2').hover(jello2);
	console.log("Работает jello");
}
export function Initjello3()
{  
	$('#effect3').hover(jello3);
	console.log("Работает jello");
}

function reset_animation() {
//setTimeout(1000);
  var el = document.querySelector('.effect2');
  el.style.animation = 'none';
  el.offsetHeight; /* trigger reflow */
  el.style.animation = null; 
  console.log("анимация закончена");
}

// Валидация
export function InitForm()
{
	$("#form1").validate(
	{
		rules: 
		{
			name: 
			{
				required: true,
				minlength: 4
			},
			email: 
			{
				required: true,
				email: true 
			},
		},
		messages: 
		{
			name: 
			{
				 required: "Обязательное поле",
				 minlength: "Длина имени не менее 4 символов"
				 
			},
			email: 
			{
				 required: "Обязательное поле",
				 email: "Неправильный формат Email" 
			},
		}
	});
}
//Диаграмма
function drawChart() 
		{
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['С',     25],
          ['PHP',      25],
          ['SQL',  20],
          ['JavaScript', 20],
          ['Html',    25]
        ]);

        var options = {
          title: '',
          backgroundColor: 'none'
          
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }

export function InitDraw()
{
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
}

//Таймер
let clock;
export function InitFlipClock()
{ 

	// Текущая дата
	var currentDate = new Date();

	// Дата начала программирования
	var pastDate  = new Date(2019,6,12);

	// Разница между датами в секундах
	var diff = currentDate.getTime() / 1000 - pastDate.getTime() / 1000;

	// Вызов таймера
	clock = $('.clock').FlipClock(diff, {
		clockFace: 'DailyCounter',
		language:'en'
	});
	    console.log("Часы подключены");		
}
