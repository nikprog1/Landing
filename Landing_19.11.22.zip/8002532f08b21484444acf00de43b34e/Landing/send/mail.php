<?php // Сообщение
//$message = "Line 1\r\nLine 2\r\nLine 3";
$message = $_POST["message"];
$email=";Email=";
$email=$email.$_POST["email"];
$name=";Name=";
$name=$name.$_POST["name"];
$message=$message.$name.$email;
// На случай если какая-то строка письма длиннее 70 символов мы используем wordwrap()
$message = wordwrap($message, 70, "\r\n");
// Отправляем
mail('gratchevnikolay@gmail.com', 'My Subject', $message);
header("Location:/Landing/index.html");
//print "стоп";

